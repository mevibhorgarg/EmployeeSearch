package org.employee.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.employee.model.Employee;
import org.employee.utils.DBConnector;



public class EmployeeDao {

	Connection conn;
	  private void connect()
	  {
		  try 
		  {
			conn=DBConnector.getConnection();
		  } 
		  catch (ClassNotFoundException e) 
		  {
			e.printStackTrace();
		  } 
		  catch (SQLException e) 
		  {
			e.printStackTrace();
		  }
		
	  }
	  
	public void addEmployee(Employee emp) {
		connect();
		String query="insert into employee (id,type) VALUES(?,?)";
		try
		{
		PreparedStatement p=conn.prepareStatement(query);
		p.setString(1,emp.getId());
		p.setString(2,emp.getType());
		int r=p.executeUpdate();
		}
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		finally
		{
			try {
				conn.close();
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
			
		}
		
	}

}
