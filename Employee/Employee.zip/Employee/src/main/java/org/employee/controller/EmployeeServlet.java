package org.employee.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.employee.model.Employee;
import org.employee.service.EmployeeService;


/**
 * Servlet implementation class EmployeeServlet
 */
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act=request.getParameter("act");
		if(act!=null)
		{
			if(act.equals("add"))
			{
				openAddEmpPage(request,response);
			}
		}
		else if(act.equals("search")){
			searchEmpPage(request,response);
		}
	}

	private void searchEmpPage(HttpServletRequest request, HttpServletResponse response) {
		try 
		{
			RequestDispatcher dis=request.getRequestDispatcher("/WEB-INF/View/SearchEmp.jsp");
			dis.forward(request, response);
		} 
		catch (ServletException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act=request.getParameter("act");
		if(act!=null)
		{
			if(act.equals("addEmp"))
			{
				addEmployee(request,response);
			}
		}
	}
	
	public void openAddEmpPage(HttpServletRequest request,HttpServletResponse response)
	{
		try 
		{
			RequestDispatcher dis=request.getRequestDispatcher("/WEB-INF/View/AddEmp.jsp");
			dis.forward(request, response);
		} 
		catch (ServletException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void addEmployee(HttpServletRequest request,HttpServletResponse response)
	{
		String type=request.getParameter("type");
		String id=request.getParameter("id");
		Employee emp=new Employee();
		emp.setId(id);
		emp.setType(type);
		EmployeeService service=new EmployeeService();
		service.addEmployee(emp);
	}
	

}
