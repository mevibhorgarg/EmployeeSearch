package org.employee.service;

import org.employee.Dao.EmployeeDao;
import org.employee.model.Employee;

public class EmployeeService {

	public void addEmployee(Employee emp) {
		EmployeeDao dao=new EmployeeDao();
		dao.addEmployee(emp);
		
	}

}
